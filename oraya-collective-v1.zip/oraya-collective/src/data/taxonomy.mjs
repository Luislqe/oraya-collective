// Controlled vocabularies used across the portfolio.
// Every asset references these keys; labels and ordering live here only.

export const verticals = {
  'real-estate': {
    label: 'Real Estate',
    numeral: 'I',
    description: 'Freehold land and premium residences, developed for long-term value.',
  },
  hospitality: {
    label: 'Hospitality',
    numeral: 'II',
    description: 'Surf houses, boutique resorts and operated hospitality assets.',
  },
  'fnb-lifestyle': {
    label: 'F&B / Lifestyle',
    numeral: 'III',
    description: 'Cafés, wellness and community spaces that anchor a destination.',
  },
};

// Status describes the asset's stage. `tone` drives colour and marker style;
// `group` drives the stage filter. Never rely on colour alone: each tone also
// has a distinct marker shape (see .status in main.css).
export const statuses = {
  operating: { label: 'Operating', tone: 'live', group: 'operating', order: 1 },
  'in-development': { label: 'In development', tone: 'progress', group: 'development', order: 2 },
  planned: { label: 'Planned development', tone: 'planned', group: 'development', order: 3 },
  'under-study': { label: 'Under study', tone: 'study', group: 'study', order: 4 },
  exited: { label: 'Exited', tone: 'exited', group: 'exited', order: 5 },
};

export const stageFilters = [
  { key: 'all', label: 'All stages' },
  { key: 'operating', label: 'Operating' },
  { key: 'development', label: 'In development' },
  { key: 'study', label: 'Under study' },
];

// How Oraya relates to an asset. `confirmed: false` types are opportunities
// and are always presented as such.
export const relationships = {
  ownership: { label: 'Ownership', confirmed: true },
  // Listed in Oraya's portfolio; ownership share not yet published.
  'portfolio-project': { label: 'Portfolio project', confirmed: true },
  'minority-under-study': { label: 'Minority participation · under study', confirmed: false },
  'development-concept': { label: 'Development concept', confirmed: false },
  'structured-financing': { label: 'Structured financing', confirmed: true },
};

// Data labels for figures. Every figure published must carry one.
export const dataKinds = {
  actual: { label: 'Actual', note: 'Reported historical figures.' },
  forecast: { label: 'Forecast', note: 'Management projection. Not a result.' },
  preliminary: { label: 'Preliminary', note: 'Early model, subject to change.' },
  projected: { label: 'Projected', note: 'Projected figures for an asset not yet operating.' },
};
