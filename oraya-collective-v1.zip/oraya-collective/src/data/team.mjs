// Team profiles. Empty until names, roles, bios and portraits are approved.
// When filled, profiles render automatically on /team/ and on the Home page.
//
// Shape:
// {
//   name: 'Full Name',
//   role: 'Founding Partner',
//   bio: 'Two or three sentences.',
//   portrait: { key: 'team-full-name', alt: 'Portrait of Full Name' }, // image in /assets-src
//   location: 'Lombok',            // optional
//   linkedin: 'https://…',         // optional
// }

export const team = [];
