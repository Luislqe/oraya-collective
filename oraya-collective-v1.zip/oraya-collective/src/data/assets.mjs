// ─────────────────────────────────────────────────────────────────────────────
// ORAYA COLLECTIVE · PORTFOLIO DATA (single source of truth for the website)
//
// Every field below is taken from the approved source-of-truth table
// (Oraya Investor Deck 2026, verified visually page by page).
//
// RULES
//  · Only publish what is confirmed. An empty / missing field is simply not
//    rendered — never write "TBC" or placeholder text in a field.
//  · `visibility: 'public'` assets get a register row and an asset page.
//    `visibility: 'private'` assets are kept here but never rendered.
//  · Every published figure needs a `kind` (actual | forecast | preliminary |
//    projected) and a `source`.
//  · Forecast / preliminary / projected VALUES are not stored here. Only a
//    description of what is available in the investor room is published.
//  · Images: keys refer to files in /assets-src (run `npm run images`).
//    Only use images attributed to the asset by a source document.
//
// ADDING AN ASSET
//  1. Add its images to /assets-src and run `npm run images`.
//  2. Copy an entry below, give it a unique `slug` and `index`.
//  3. `npm run build` — register, gallery, Collective diagram, filters,
//     asset page, related assets, sitemap and structured data update.
// ─────────────────────────────────────────────────────────────────────────────

export const assets = [
  {
    slug: 'twinfin',
    index: 1,
    name: 'TwinFin',
    visibility: 'public',
    featured: true,
    vertical: 'hospitality',
    descriptor: 'Boutique surf house · 10 rooms',
    location: 'Lombok, Indonesia',
    region: 'Lombok',
    status: 'operating',
    since: '2025',
    relationship: { type: 'ownership', participation: '49%' },
    summary:
      'A ten-room boutique surf house in Lombok, generating revenue since 2025 — the first asset in the collective to trade, and our proof of execution.',
    overview: [
      'TwinFin is a boutique surf house of ten rooms — five doubles and five quadruples — on a 1,000 m² plot in Lombok, with 200 m² of shared space.',
      'Guests have a café, a fitness room, a pool and parking, with surf and yoga lessons on site. The house has generated revenue since 2025.',
    ],
    thesis:
      'The right size to fill, to form a community and to hold healthy margins — the pattern Oraya intends to carry across the rest of the portfolio.',
    facts: [
      { label: 'Rooms', value: '10 · 5 double + 5 quadruple' },
      { label: 'Plot', value: '1,000 m²' },
      { label: 'Shared space', value: '200 m²' },
      { label: 'Tenure', value: 'Leasehold · 35 years' },
      { label: 'Facilities', value: 'Café · fitness room · pool · parking' },
      { label: 'Activities', value: 'Surf lessons · yoga classes' },
    ],
    actualMetrics: {
      kind: 'actual',
      title: 'Operating results, January–May 2026',
      periods: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
      rows: [
        { label: 'Occupancy', unit: '%', values: [59, 79, 48, 56, 75] },
        { label: 'Sales', unit: '€k', values: [11.6, 13.7, 12.8, 18.3, 20.8] },
      ],
      source: 'Oraya Collective Investor Deck, 2026 (p. 9)',
    },
    investorRoom: {
      kind: 'forecast',
      items: [
        'Full-year 2026 forecast: sales, net income and occupancy',
        'Monthly forecast, June–December 2026',
        'Net income by month, January–May 2026',
      ],
    },
    images: {
      hero: { key: 'twinfin-exterior', alt: 'Two-storey white building with arched balconies, palm trees, sun loungers and a pool' },
      gallery: [],
    },
    sources: ['Oraya Collective Investor Deck, 2026 — pp. 6–9'],
  },

  {
    slug: 'areguling',
    index: 2,
    name: 'Areguling',
    visibility: 'public',
    featured: false,
    vertical: 'real-estate',
    descriptor: 'Coastal freehold land · six residences planned',
    location: 'South Lombok · beachfront',
    region: 'South Lombok',
    status: 'planned',
    relationship: { type: 'portfolio-project' },
    summary:
      'A coastal freehold plot in the south of Lombok with open sea views, planned for six high-end residences.',
    overview: [
      'A 3,000 m² coastal freehold plot — full ownership rather than leasehold — in the south of Lombok, with open views over the sea.',
      'The project plans six high-end villas on the site.',
    ],
    thesis: 'Scarce freehold coastal land with open sea views and development upside.',
    facts: [
      { label: 'Land', value: '3,000 m²' },
      { label: 'Tenure', value: 'Freehold · full ownership' },
      { label: 'Project', value: '6 high-end villas' },
      { label: 'Location', value: 'South Lombok · beachfront' },
    ],
    investorRoom: {
      kind: 'forecast',
      items: ['Total investment and five-year projections across three scenarios'],
    },
    images: {
      hero: { key: 'areguling-coast', alt: 'Coastal landscape with palm groves, a bay and a green headland' },
      gallery: [],
    },
    sources: ['Oraya Collective Investor Deck, 2026 — pp. 10–12'],
  },

  {
    slug: 'beach-club-mandalika',
    index: 3,
    name: 'Beach club, Mandalika',
    visibility: 'public',
    featured: false,
    vertical: 'fnb-lifestyle',
    descriptor: 'Beachfront F&B, leisure and events',
    location: 'Mandalika, South Lombok',
    region: 'South Lombok',
    status: 'under-study',
    relationship: { type: 'minority-under-study' },
    summary:
      'A beachfront club in Mandalika — dining, leisure and events under professional operation — in which a minority participation is under study.',
    overview: [
      'A beachfront beach club in Mandalika, in the south of Lombok: restaurant, leisure and events, under professional operation.',
      'Oraya is studying a minority participation. The data is preliminary and the operation remains under study.',
    ],
    thesis: 'Beachfront F&B and events in Mandalika, the focus of south Lombok’s growth.',
    facts: [
      { label: 'Model', value: 'F&B + events · leasehold' },
      { label: 'Location', value: 'Mandalika, South Lombok' },
      { label: 'Operation', value: 'Professional management' },
    ],
    investorRoom: {
      kind: 'preliminary',
      items: ['Preliminary business plan and model returns'],
    },
    images: {
      hero: { key: 'beachclub-aerial', alt: 'Aerial view of a beach club with thatched roofs and pools along a sandy shore' },
      gallery: [{ key: 'beachclub-evening', alt: 'An evening crowd gathered under string lights and palm trees' }],
    },
    sources: ['Oraya Collective Investor Deck, 2026 — pp. 13–16'],
  },

  {
    slug: 'ritmo',
    index: 4,
    name: 'Ritmo',
    visibility: 'public',
    featured: false,
    vertical: 'fnb-lifestyle',
    descriptor: 'Specialty café and wellness studio',
    location: 'South coast of Lombok',
    region: 'South Lombok',
    status: 'in-development',
    relationship: { type: 'development-concept' },
    summary:
      'A hybrid specialty café and indoor-cycling studio conceived as a community anchor on Lombok’s south coast. Not yet operating.',
    overview: [
      'An indoor-cycling studio with specialty coffee, brunch and açaí: a community and wellbeing anchor in a strategic location on Lombok’s south coast.',
      'Ritmo is in development and not yet operating.',
    ],
    thesis: 'Café and wellness as a daily anchor for the community.',
    facts: [
      { label: 'Concept', value: 'Indoor cycling (26 bikes) · specialty coffee · brunch & açaí' },
      { label: 'Location', value: 'South coast of Lombok' },
    ],
    investorRoom: {
      kind: 'projected',
      items: ['Projected business plan (realistic scenario)'],
    },
    images: { hero: null, gallery: [] },
    sources: ['Oraya Collective Investor Deck, 2026 — pp. 20–22'],
  },

  // Kept private: Oraya's role as lender is not explicitly confirmed in the
  // approved source. Set visibility to 'public' only once it is.
  {
    slug: 'sora',
    index: 5,
    name: 'SORA',
    visibility: 'private',
    featured: false,
    vertical: 'hospitality',
    descriptor: 'Boutique resort · 15 keys',
    location: 'Kuta-Mandalika, South Lombok',
    region: 'South Lombok',
    status: 'in-development',
    relationship: { type: 'structured-financing' },
    summary: 'Structured land financing for a fifteen-key boutique resort.',
    overview: [],
    facts: [
      { label: 'Keys', value: '15' },
      { label: 'Tenure', value: 'Leasehold · 40 years' },
    ],
    images: { hero: null, gallery: [] },
    sources: ['Oraya Collective Investor Deck, 2026 — pp. 17–19'],
  },
];

export const publicAssets = assets
  .filter((a) => a.visibility === 'public')
  .sort((a, b) => a.index - b.index);
