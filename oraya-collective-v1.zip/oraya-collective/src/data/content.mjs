// Company-level content used across pages. All factual statements trace to
// the Oraya Collective Investor Deck (2026); page references in comments.

export const model = [
  {
    key: 'build',
    numeral: 'i',
    title: 'Build',
    text: 'We create businesses and developments from the ground up, identifying opportunities and turning them into operating assets.',
    example: 'Areguling · Ritmo',
  },
  {
    key: 'acquire',
    numeral: 'ii',
    title: 'Acquire',
    text: 'We invest in existing businesses, land and strategic opportunities where we see significant potential.',
    example: 'TwinFin · 49% ownership',
  },
  {
    key: 'operate',
    numeral: 'iii',
    title: 'Operate',
    text: 'We stay actively involved in our businesses and assets — through a local operating company licensed for hospitality and F&B in Indonesia.',
    example: 'PT Oraya Collective Indonesia',
  },
  {
    key: 'grow',
    numeral: 'iv',
    title: 'Grow',
    text: 'We carry capital, experience and relationships into the next generation of opportunities, scaling across verticals without multiplying structure.',
    example: 'Across all verticals',
  },
];

// Deck p.5
export const platform = [
  { title: 'Pipeline and local execution', text: 'Deal flow in the south of Lombok, with an in-country team.' },
  { title: 'Brand and operating leverage', text: 'One umbrella brand that carries learning from one vertical to the next.' },
  { title: 'Scale across verticals', text: 'Hospitality, F&B and residential share infrastructure and channels.' },
];

// Deck p.2–3. Figures are as presented in Oraya's investor materials.
export const lombok = {
  intro:
    'Lombok sits a short step east of Bali — far less developed, with its trajectory still ahead. We believe it offers what Bali offered two decades ago: an early entry, with planned infrastructure.',
  points: [
    { figure: '45 min', label: 'by air from Bali', text: 'Bali’s smaller neighbour, a short step east — far less developed, with its trajectory still ahead.' },
    { figure: '1.2M', label: 'guests in 2025', text: 'Visitor numbers doubled between 2023 and 2025.' },
    { figure: 'Mandalika', label: 'MotoGP circuit', text: 'A newly built circuit drawing around 140,000 attendees and an estimated US$289M in economic impact each October.' },
    { figure: 'From zero', label: 'planned infrastructure', text: 'Tourism infrastructure planned from the outset, without the legacy congestion of Bali. Land remains largely in the hands of local owners.' },
  ],
  sourceNote: 'Figures as presented in Oraya Collective’s 2026 investor materials.',
};

// Deck p.23
export const structure = [
  { n: '01', name: 'The Oraya Collective SL', place: 'Spain', role: 'Investor-facing company: distributions, governance and investor relations.' },
  { n: '02', name: 'PT Oraya Collective Indonesia', place: 'Indonesia', role: 'Local operating company, licensed to manage hospitality and F&B in Indonesia.' },
  { n: '03', name: 'One vehicle per asset', place: 'Per project', role: 'Each asset is held in its own ring-fenced, transparent vehicle, aligned with investors.' },
];

// Deck p.25 (selected, non-promissory statements only)
export const alignment = [
  { title: 'Skin in the game', text: 'The founders hold equity in every project vehicle.' },
  { title: 'Preferred access', text: 'An established local network and our own deal flow.' },
  { title: 'Not starting from zero', text: 'An operating asset is already trading.' },
  { title: 'Diversified by design', text: 'Several verticals and several ownership models.' },
];
