// Global site configuration.
// SITE_URL resolution: explicit SITE_URL env var → Netlify's primary URL (set
// automatically on every Netlify build, and equal to the custom domain once it
// is connected) → local fallback.

export const site = {
  name: 'Oraya Collective',
  legalNames: ['The Oraya Collective SL', 'PT Oraya Collective Indonesia'],
  url: (process.env.SITE_URL || process.env.URL || 'http://localhost:4321').replace(/\/$/, ''),
  locale: 'en',
  tagline: 'An Indonesia-focused investment holding company.',
  description:
    'Oraya Collective is an Indonesia-focused investment holding company building, acquiring and operating businesses and real assets across real estate, hospitality and lifestyle — beginning in Lombok.',
  ogImage: 'brand-cover',
  // Public contact details are intentionally empty until confirmed.
  // When added, they render automatically in the footer and investor page.
  contact: {
    email: '',
    phone: '',
    address: '',
  },
};

export const nav = [
  { label: 'Collective', href: '/collective/' },
  { label: 'Portfolio', href: '/portfolio/' },
  { label: 'Approach', href: '/approach/' },
  { label: 'Team', href: '/team/' },
];

export const cta = { label: 'Investor access', href: '/investor-access/' };

export const legalNav = [
  { label: 'Investment disclaimer', href: '/legal/investment-disclaimer/' },
  { label: 'Privacy', href: '/legal/privacy/' },
  { label: 'Terms of use', href: '/legal/terms/' },
  { label: 'Cookies', href: '/legal/cookies/' },
];
