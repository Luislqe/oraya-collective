import { html, esc, when } from '../lib/html.mjs';
import { imageUrl } from '../lib/image.mjs';
import { site, nav, cta, legalNav } from '../config/site.mjs';

const wordmark = (cls = '') => html`<a href="/" class="wordmark ${cls}" aria-label="Oraya Collective — home">
  <span class="wordmark__main">ORAYA</span><span class="wordmark__sub">COLLECTIVE</span></a>`;

const arrow = '<span class="arrow" aria-hidden="true">→</span>';

function header({ path, theme }) {
  const link = (n) => {
    const current = path.startsWith(n.href);
    return html`<a href="${n.href}" class="nav__link"${current ? ' aria-current="page"' : ''}>${esc(n.label)}</a>`;
  };
  return html`
<header class="site-header" data-theme="${theme}" data-header>
  <div class="site-header__inner">
    ${wordmark()}
    <nav class="nav" aria-label="Primary">
      ${nav.map(link)}
      <a href="${cta.href}" class="btn btn--line nav__cta"${path.startsWith(cta.href) ? ' aria-current="page"' : ''}>${esc(cta.label)}${arrow}</a>
    </nav>
    <button class="menu-toggle" type="button" aria-expanded="false" aria-controls="menu" data-menu-open>
      <span class="menu-toggle__label">Menu</span><span class="menu-toggle__icon" aria-hidden="true"><i></i><i></i></span>
    </button>
  </div>
</header>
<div class="menu" id="menu" role="dialog" aria-modal="true" aria-label="Menu" hidden data-menu>
  <div class="menu__top">
    ${wordmark('wordmark--light')}
    <button class="menu-close" type="button" data-menu-close>Close <span aria-hidden="true">×</span></button>
  </div>
  <nav class="menu__nav" aria-label="Mobile">
    <a href="/" class="menu__link">Home</a>
    ${nav.map((n) => html`<a href="${n.href}" class="menu__link"${path.startsWith(n.href) ? ' aria-current="page"' : ''}>${esc(n.label)}</a>`)}
  </nav>
  <div class="menu__foot">
    <a href="${cta.href}" class="btn btn--solid-light btn--block">${esc(cta.label)}${arrow}</a>
    <p class="menu__entities">${site.legalNames.map(esc).join(' · ')}</p>
  </div>
</div>`;
}

function footer() {
  const c = site.contact;
  return html`
<footer class="site-footer">
  <div class="wrap">
    <div class="site-footer__top">
      <div class="site-footer__brand">
        ${wordmark('wordmark--light wordmark--lg')}
        <p class="site-footer__line">An Indonesia-focused investment holding company.</p>
      </div>
      <nav class="site-footer__nav" aria-label="Footer">
        <p class="label label--mist">Site</p>
        <a href="/">Home</a>
        ${nav.map((n) => html`<a href="${n.href}">${esc(n.label)}</a>`)}
        <a href="${cta.href}">${esc(cta.label)}</a>
      </nav>
      <nav class="site-footer__nav" aria-label="Legal">
        <p class="label label--mist">Legal</p>
        ${legalNav.map((n) => html`<a href="${n.href}">${esc(n.label)}</a>`)}
      </nav>
      <div class="site-footer__nav">
        <p class="label label--mist">Entities</p>
        ${site.legalNames.map((n) => html`<span>${esc(n)}</span>`)}
        ${when(c.email, () => html`<a href="mailto:${esc(c.email)}">${esc(c.email)}</a>`)}
        ${when(c.phone, () => html`<span>${esc(c.phone)}</span>`)}
        ${when(c.address, () => html`<span>${esc(c.address)}</span>`)}
      </div>
    </div>
    <p class="site-footer__disclaimer">The information on this website is provided for general information only. It does not constitute an offer to sell, or a solicitation of an offer to buy, any security or investment, and must not be relied upon as investment, legal or tax advice. Figures labelled forecast, preliminary or projected are estimates and may not be achieved. See the <a href="/legal/investment-disclaimer/">investment disclaimer</a>.</p>
    <div class="site-footer__bottom">
      <span>© ${new Date().getFullYear()} The Oraya Collective SL</span>
      <span>Indonesia · Lombok</span>
    </div>
  </div>
</footer>`;
}

/**
 * Page shell.
 * @param {object} p { path, title, description, body, theme ('dark'|'light'), ogImage, noindex, jsonld, stickyCta }
 */
export function layout(p) {
  const {
    path,
    title,
    description = site.description,
    body,
    theme = 'light',
    ogImage = site.ogImage,
    noindex = false,
    jsonld = [],
    stickyCta = true,
  } = p;
  const fullTitle = path === '/' ? `${site.name} — ${title}` : `${title} — ${site.name}`;
  const canonical = site.url + path;
  const og = site.url + imageUrl(ogImage, 1200);
  const org = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: site.name,
    legalName: site.legalNames[0],
    url: site.url,
    description: site.tagline,
    areaServed: 'Indonesia',
  };
  return html`<!doctype html>
<html lang="${site.locale}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${esc(fullTitle)}</title>
<meta name="description" content="${esc(description)}">
<link rel="canonical" href="${esc(canonical)}">
${noindex ? '<meta name="robots" content="noindex, follow">' : ''}
<meta name="theme-color" content="#191816">
<meta property="og:type" content="website">
<meta property="og:site_name" content="${site.name}">
<meta property="og:title" content="${esc(fullTitle)}">
<meta property="og:description" content="${esc(description)}">
<meta property="og:url" content="${esc(canonical)}">
<meta property="og:image" content="${esc(og)}">
<meta property="og:locale" content="en_GB">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Instrument+Sans:wght@400;500;600&family=Instrument+Serif:ital@0;1&display=swap">
<link rel="stylesheet" href="/assets/main.css">
<script type="application/ld+json">${JSON.stringify([org, ...jsonld])}</script>
<script>document.documentElement.classList.add('js')</script>
</head>
<body class="theme-${theme}">
<a href="#main" class="skip-link">Skip to content</a>
${header({ path, theme })}
<main id="main">
${body}
</main>
${footer()}
${when(stickyCta, () => html`<div class="sticky-cta" data-sticky-cta>
  <span class="sticky-cta__text">Oraya Collective</span>
  <a href="${cta.href}" class="btn btn--solid btn--sm">${esc(cta.label)}</a>
</div>`)}
<script src="/assets/main.js" defer></script>
</body>
</html>
`;
}

export { arrow, wordmark };
