import { html, esc, when } from '../lib/html.mjs';
import { picture } from '../lib/image.mjs';
import { verticals, statuses, relationships, stageFilters, dataKinds } from '../data/taxonomy.mjs';
import { arrow } from './layout.mjs';

export const pad = (n) => String(n).padStart(2, '0');

export const relationshipText = (a) => {
  const r = relationships[a.relationship?.type];
  if (!r) return '';
  return a.relationship.participation ? `${r.label} · ${a.relationship.participation}` : r.label;
};

export const statusTag = (key, extra = '') => {
  const s = statuses[key];
  return html`<span class="status status--${s.tone} ${extra}"><span class="status__mark" aria-hidden="true"></span>${esc(s.label)}</span>`;
};

export const dataLabel = (kind) => html`<span class="data-label data-label--${kind}">${esc(dataKinds[kind].label)}</span>`;

export function sectionHead({ n, label, light = false }) {
  return html`<div class="section-head${light ? ' section-head--light' : ''}" data-reveal>
    ${when(n, () => html`<span class="section-head__n">${esc(n)}</span>`)}<span>${esc(label)}</span></div>`;
}

export function textLink(href, label, light = false) {
  return html`<a href="${href}" class="text-link${light ? ' text-link--light' : ''}">${esc(label)}${arrow}</a>`;
}

/** Typographic tile used when an asset has no approved photography. */
export function fallbackTile(a, cls = '') {
  return html`<div class="tile ${cls}"><span class="label">${esc(verticals[a.vertical].label)}</span><span class="tile__name">${esc(a.name)}</span></div>`;
}

export function assetVisual(a, o = {}) {
  if (a.images?.hero) return picture(a.images.hero.key, { alt: a.images.hero.alt, ...o });
  return fallbackTile(a, o.tileClass || '');
}

// ── Collective diagram: generated from the portfolio data ─────────────────────
export function collectiveDiagram(list) {
  const col = (key) => {
    const v = verticals[key];
    const items = list.filter((a) => a.vertical === key);
    return html`<div class="diagram__col">
      <span class="diagram__stem" aria-hidden="true"></span>
      <span class="diagram__numeral">${v.numeral}</span>
      <h3 class="diagram__vertical">${esc(v.label)}</h3>
      <p class="diagram__desc">${esc(v.description)}</p>
      <ul class="diagram__assets">
        ${items.map((a) => html`<li><a href="/portfolio/${a.slug}/"><span class="diagram__asset">${esc(a.name)}</span>${statusTag(a.status, 'status--sm')}</a></li>`)}
      </ul>
    </div>`;
  };
  return html`<figure class="diagram" data-reveal data-diagram aria-label="Structure of the collective: one investment in Oraya Collective, held across three verticals">
    <span class="diagram__eyebrow label">Your investment</span>
    <span class="diagram__line diagram__line--v" aria-hidden="true"></span>
    <div class="diagram__core">
      <span class="diagram__core-name">Oraya Collective</span>
      <span class="label">Investment holding company</span>
    </div>
    <span class="diagram__line diagram__line--v" aria-hidden="true"></span>
    <div class="diagram__cols">
      <span class="diagram__line diagram__line--h" aria-hidden="true"></span>
      ${Object.keys(verticals).map(col)}
      <div class="diagram__col diagram__col--next">
        <span class="diagram__stem diagram__stem--dashed" aria-hidden="true"></span>
        <span class="diagram__numeral">—</span>
        <h3 class="diagram__vertical"><em>What comes next</em></h3>
        <p class="diagram__desc">New acquisitions, developments and strategic positions.</p>
      </div>
    </div>
  </figure>`;
}

// ── Portfolio register ─────────────────────────────────────────────────────────
function registerRow(a) {
  const v = verticals[a.vertical];
  const s = statuses[a.status];
  return html`<li class="reg-row" data-item data-vertical="${a.vertical}" data-stage="${s.group}" data-index="${a.index}" data-name="${esc(a.name)}" data-order="${s.order}" data-preview="${a.slug}">
    <a href="/portfolio/${a.slug}/" class="reg-row__link">
      <span class="reg-row__n">${pad(a.index)}</span>
      <span class="reg-row__asset"><span class="reg-row__name">${esc(a.name)}</span><span class="reg-row__desc">${esc(a.descriptor)}</span></span>
      <span class="reg-row__cell" data-col="Vertical">${esc(v.label)}</span>
      <span class="reg-row__cell reg-row__cell--loc" data-col="Location">${esc(a.region || a.location)}</span>
      <span class="reg-row__cell" data-col="Oraya">${esc(relationshipText(a))}</span>
      <span class="reg-row__cell reg-row__cell--status">${statusTag(a.status)}</span>
      <span class="reg-row__go" aria-hidden="true">→</span>
    </a>
  </li>`;
}

function galleryCard(a, i) {
  const shape = ['tall', 'wide', 'square'][i % 3];
  return html`<li class="gal-card gal-card--${shape}" data-item data-vertical="${a.vertical}" data-stage="${statuses[a.status].group}" data-index="${a.index}" data-name="${esc(a.name)}" data-order="${statuses[a.status].order}">
    <a href="/portfolio/${a.slug}/">
      <div class="gal-card__media">${assetVisual(a, { sizes: '(max-width: 760px) 86vw, 40vw', tileClass: 'tile--fill' })}</div>
      <div class="gal-card__meta"><span>${pad(a.index)} — ${esc(a.name)}</span>${statusTag(a.status, 'status--sm')}</div>
      <span class="gal-card__sub">${esc(verticals[a.vertical].label)} · ${esc(relationshipText(a))}</span>
    </a>
  </li>`;
}

/**
 * Interactive register. Renders complete, accessible markup; JS enhances it
 * with filtering, sorting, view switching and hover previews.
 * @param {Array} list    public assets
 * @param {object} o      { compact: bool, id }
 */
export function register(list, o = {}) {
  const { compact = false, id = 'register' } = o;
  const vFilters = [{ key: 'all', label: 'All' }, ...Object.entries(verticals).map(([key, v]) => ({ key, label: v.label }))];
  const btn = (group, f, i) =>
    html`<button type="button" class="chip" data-filter="${group}" data-value="${f.key}" aria-pressed="${i === 0}">${esc(f.label)}</button>`;
  const previews = list.filter((a) => a.images?.hero);
  return html`<div class="register${compact ? ' register--compact' : ''}" id="${id}" data-register>
    <div class="register__bar" data-reveal>
      <div class="register__filters">
        <div class="chips" role="group" aria-label="Filter by vertical">${vFilters.map((f, i) => btn('vertical', f, i))}</div>
        ${when(!compact, () => html`<div class="chips" role="group" aria-label="Filter by stage">${stageFilters.map((f, i) => btn('stage', f, i))}</div>`)}
      </div>
      <div class="register__tools">
        <span class="register__count" aria-live="polite" data-count>${pad(list.length)} of ${pad(list.length)}</span>
        ${when(!compact, () => html`<label class="register__sort"><span class="visually-hidden">Sort</span>
          <select data-sort>
            <option value="index">Sort · Register no.</option>
            <option value="name">Sort · Name</option>
            <option value="order">Sort · Stage</option>
          </select></label>`)}
        <div class="views" role="group" aria-label="View">
          <button type="button" class="chip" data-view="register" aria-pressed="true">Register</button>
          <button type="button" class="chip" data-view="gallery" aria-pressed="false">Gallery</button>
        </div>
      </div>
    </div>

    <div class="register__body">
      <div class="register__list" data-panel="register">
        <div class="reg-head" aria-hidden="true">
          <span>No.</span><span>Asset</span><span>Vertical</span><span class="reg-head__loc">Location</span><span>Oraya’s relationship</span><span>Status</span><span></span>
        </div>
        <ol class="reg-rows" data-items>${list.map(registerRow)}</ol>
        <p class="register__empty" data-empty hidden>No positions match this view.</p>
        <p class="register__open"><span>—</span><em>The register remains open. New positions are added as they are made.</em></p>
      </div>
      <ol class="gallery" data-panel="gallery" data-items hidden>${list.map(galleryCard)}</ol>
      <div class="reg-preview" aria-hidden="true" data-preview-box>
        ${previews.map((a) => html`<div class="reg-preview__img" data-preview-for="${a.slug}">${picture(a.images.hero.key, { alt: '', sizes: '280px' })}</div>`)}
      </div>
    </div>
  </div>`;
}

// ── Ledger (key-value strip) ───────────────────────────────────────────────────
export function ledger(items, light = false) {
  return html`<dl class="ledger${light ? ' ledger--light' : ''}">${items
    .filter((i) => i && i.value)
    .map((i) => html`<div class="ledger__item"><dt class="label">${esc(i.label)}</dt><dd>${i.html ?? esc(i.value)}</dd></div>`)}</dl>`;
}

// ── Actual metrics table ───────────────────────────────────────────────────────
export function metricsTable(m, light = false) {
  const fmt = (v, unit) => (unit === '%' ? `${v}%` : String(v).replace('.', '.'));
  return html`<figure class="metrics${light ? ' metrics--light' : ''}">
    <figcaption class="metrics__head">${dataLabel(m.kind)}<span>${esc(m.title)}</span></figcaption>
    <div class="metrics__scroll">
      <table>
        <thead><tr><th scope="col"><span class="visually-hidden">Metric</span></th>${m.periods.map((p) => html`<th scope="col">${esc(p)}</th>`)}</tr></thead>
        <tbody>${m.rows.map((r) => html`<tr><th scope="row">${esc(r.label)}${r.unit !== '%' ? html` <span class="metrics__unit">(${esc(r.unit)})</span>` : ''}</th>${r.values.map((v) => html`<td>${fmt(v, r.unit)}</td>`)}</tr>`)}</tbody>
      </table>
    </div>
    <p class="metrics__source">Source: ${esc(m.source)}.</p>
  </figure>`;
}

export function investorRoomPanel(room, light = false) {
  if (!room) return '';
  return html`<aside class="room${light ? ' room--light' : ''}" aria-label="Investor room">
    <div class="room__head">${dataLabel(room.kind)}<span class="label">Investor room</span></div>
    <ul class="room__list">${room.items.map((i) => html`<li>${esc(i)}</li>`)}</ul>
    <p class="room__note">${esc(dataKinds[room.kind].note)} Shared privately with qualified investors after an introductory conversation.</p>
    <a href="/investor-access/" class="text-link${light ? ' text-link--light' : ''}">Request investor information${arrow}</a>
  </aside>`;
}

export function ctaBand({ title, text, button = 'Request investor information', href = '/investor-access/' }) {
  return html`<section class="cta-band">
    <div class="wrap cta-band__inner">
      <h2 class="display-l" data-reveal>${title}</h2>
      <div class="cta-band__side" data-reveal>
        <p class="lead">${esc(text)}</p>
        <a href="${href}" class="btn btn--solid-light">${esc(button)}${arrow}</a>
      </div>
    </div>
  </section>`;
}

export function pageHero({ eyebrow, title, intro, n }) {
  return html`<section class="page-hero">
    <div class="wrap">
      ${sectionHead({ n, label: eyebrow })}
      <div class="page-hero__grid">
        <h1 class="display-xl" data-reveal>${title}</h1>
        ${when(intro, () => html`<p class="lead page-hero__intro" data-reveal>${esc(intro)}</p>`)}
      </div>
    </div>
  </section>`;
}
