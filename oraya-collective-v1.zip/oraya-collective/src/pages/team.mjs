import { html, esc, when } from '../lib/html.mjs';
import { picture } from '../lib/image.mjs';
import { layout } from '../components/layout.mjs';
import { sectionHead, pageHero, ctaBand } from '../components/ui.mjs';
import { team } from '../data/team.mjs';
import { alignment, structure } from '../data/content.mjs';

export function teamGrid(list) {
  return html`<ul class="team-grid">${list.map((p) => html`<li class="person" data-reveal>
    ${when(p.portrait, () => html`<div class="person__media">${picture(p.portrait.key, { alt: p.portrait.alt, sizes: '(max-width: 760px) 100vw, 25vw' })}</div>`)}
    <h3 class="person__name">${esc(p.name)}</h3>
    <p class="label">${esc(p.role)}${p.location ? ` · ${esc(p.location)}` : ''}</p>
    ${when(p.bio, () => html`<p class="person__bio">${esc(p.bio)}</p>`)}
    ${when(p.linkedin, () => html`<a class="text-link" href="${esc(p.linkedin)}" rel="noopener">LinkedIn</a>`)}
  </li>`)}</ul>`;
}

export function teamPage() {
  const body = html`
${pageHero({ eyebrow: 'Team', title: 'The people<br><em>behind Oraya.</em>', intro: 'A holding company is only as good as the people who run it. Oraya is led by its founders and operated by an in-country team, through its own local company.' })}

${when(team.length, () => html`<section class="section section--flush-top"><div class="wrap">${sectionHead({ label: 'Leadership' })}${teamGrid(team)}</div></section>`)}

<section class="section section--flush-top">
  <div class="wrap">
    ${sectionHead({ n: '01', label: 'How we are organised' })}
    <div class="split">
      <h2 class="display-l split__main" data-reveal>On the ground,<br><em>in Indonesia.</em></h2>
      <div class="split__side" data-reveal>
        <p class="lead">Deal flow in the south of Lombok is sourced and executed by our own team in the country.</p>
        <p>Operations run through PT Oraya Collective Indonesia, our local company licensed to manage hospitality and F&amp;B. Investor relations, governance and distributions sit with The Oraya Collective SL in Spain.</p>
      </div>
    </div>
    <ol class="layers">${structure.map((s) => html`<li class="layers__item" data-reveal><span class="layers__n">${s.n}</span><span class="layers__name">${esc(s.name)}</span><span class="label">${esc(s.place)}</span><p>${esc(s.role)}</p></li>`)}</ol>
  </div>
</section>

<section class="section section--stone">
  <div class="wrap">
    ${sectionHead({ n: '02', label: 'Alignment' })}
    <h2 class="display-l" data-reveal>Our capital<br><em>sits next to yours.</em></h2>
    <div class="principles">${alignment.map((a) => html`<div class="principles__item" data-reveal><h3>${esc(a.title)}</h3><p>${esc(a.text)}</p></div>`)}</div>
  </div>
</section>

${ctaBand({ title: 'Meet the team<br><em>in person.</em>', text: 'Introductions begin with a private conversation with one of the founders.' })}`;

  return layout({
    path: '/team/',
    title: 'Team',
    description: 'Oraya Collective is led by its founders, who hold equity in every project vehicle, and operated by an in-country team in Indonesia.',
    body,
  });
}
