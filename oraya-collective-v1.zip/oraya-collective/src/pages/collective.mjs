import { html, esc } from '../lib/html.mjs';
import { picture } from '../lib/image.mjs';
import { layout } from '../components/layout.mjs';
import { sectionHead, pageHero, collectiveDiagram, ctaBand, textLink } from '../components/ui.mjs';
import { publicAssets } from '../data/assets.mjs';
import { model, platform, structure, alignment } from '../data/content.mjs';

export function collectivePage() {
  const body = html`
${pageHero({
  eyebrow: 'The Collective',
  title: 'One company.<br><em>A portfolio of assets.</em>',
  intro: 'Oraya Collective is an Indonesia-focused investment holding company. We build, acquire and operate businesses and real assets across real estate, hospitality and lifestyle — beginning in Lombok.',
})}

<section class="section section--flush-top">
  <div class="wrap">
    <figure class="wide-figure" data-reveal="image">
      ${picture('brand-cover', { alt: 'Palm trees and a pool terrace above the sea at dusk', sizes: '100vw', position: '50% 55%' })}
    </figure>
  </div>
</section>

<section class="section">
  <div class="wrap">
    ${sectionHead({ n: '01', label: 'What Oraya is' })}
    <div class="split">
      <h2 class="display-l split__main" data-reveal>We don’t invest in projects.<br><em>We build a portfolio.</em></h2>
      <div class="split__side" data-reveal>
        <p class="lead">An investor in Oraya does not pick a single villa. They take a position in the company — and through it, in the collective.</p>
        <p>Each asset is held in its own vehicle, at its own stage and under the ownership model that suits it: an operating business, land held for development, a minority participation, or a new concept in development.</p>
      </div>
    </div>
    ${collectiveDiagram(publicAssets)}
  </div>
</section>

<section class="section section--dark">
  <div class="wrap">
    ${sectionHead({ n: '02', label: 'Philosophy', light: true })}
    <h2 class="display-l" data-reveal>Not isolated projects.<br><em>A platform.</em></h2>
    <ol class="rows rows--light">
      ${platform.map((p, i) => html`<li class="rows__item" data-reveal><span class="rows__n">0${i + 1}</span><h3 class="rows__title">${esc(p.title)}</h3><p>${esc(p.text)}</p></li>`)}
    </ol>
  </div>
</section>

<section class="section">
  <div class="wrap">
    ${sectionHead({ n: '03', label: 'Our model' })}
    <h2 class="display-l model-title" data-reveal>Build. Acquire.<br>Operate. <em>Grow.</em></h2>
    <ol class="model">
      ${model.map((m) => html`<li class="model__item" data-reveal><span class="model__n">${m.numeral}</span><h3 class="model__title">${esc(m.title)}</h3><p>${esc(m.text)}</p><span class="model__ex label">${esc(m.example)}</span></li>`)}
    </ol>
  </div>
</section>

<section class="section section--stone">
  <div class="wrap">
    ${sectionHead({ n: '04', label: 'Geographic focus' })}
    <div class="split">
      <h2 class="display-l split__main" data-reveal>Indonesia.<br><em>Lombok first.</em></h2>
      <div class="split__side" data-reveal>
        <p class="lead">Indonesia is our frame. Lombok — and its south coast in particular — is where the collective begins.</p>
        <p>Every current position is in Lombok. We diversify across verticals and ownership models today, and intend to extend across Indonesia as the collective grows.</p>
        ${textLink('/approach/', 'Why Lombok, and how we invest')}
      </div>
    </div>
  </div>
</section>

<section class="section">
  <div class="wrap">
    ${sectionHead({ n: '05', label: 'Structure' })}
    <div class="split">
      <h2 class="display-l split__main" data-reveal>Three layers.<br><em>One capital stack.</em></h2>
      <p class="split__side lead" data-reveal>A Spanish holding for investors, an Indonesian operating company on the ground, and one ring-fenced vehicle for each asset.</p>
    </div>
    <ol class="layers">${structure.map((s) => html`<li class="layers__item" data-reveal><span class="layers__n">${s.n}</span><span class="layers__name">${esc(s.name)}</span><span class="label">${esc(s.place)}</span><p>${esc(s.role)}</p></li>`)}</ol>
  </div>
</section>

<section class="section section--flush-top">
  <div class="wrap">
    ${sectionHead({ n: '06', label: 'Long-term vision' })}
    <div class="split">
      <h2 class="display-l split__main" data-reveal>We’re not starting.<br><em>We’re scaling.</em></h2>
      <div class="split__side" data-reveal>
        <p class="lead">One asset already trades. The rest of the collective is built on the same pattern: small, well-run businesses and well-located land, operated by our own in-country team.</p>
      </div>
    </div>
    <div class="principles">${alignment.map((a) => html`<div class="principles__item" data-reveal><h3>${esc(a.title)}</h3><p>${esc(a.text)}</p></div>`)}</div>
  </div>
</section>

${ctaBand({ title: 'Invest in the company<br><em>behind the projects.</em>', text: 'The portfolio, its operating data and its structure are shared in a private conversation.' })}`;

  return layout({
    path: '/collective/',
    title: 'The Collective',
    description: 'One company, a portfolio of assets. How Oraya Collective builds, acquires and operates businesses and real assets across Indonesia, beginning in Lombok.',
    body,
  });
}
