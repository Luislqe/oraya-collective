import { html, esc, when } from '../lib/html.mjs';
import { picture } from '../lib/image.mjs';
import { layout, arrow } from '../components/layout.mjs';
import { sectionHead, collectiveDiagram, register, metricsTable, investorRoomPanel, textLink, ledger, relationshipText, statusTag } from '../components/ui.mjs';
import { publicAssets } from '../data/assets.mjs';
import { model, lombok, alignment } from '../data/content.mjs';
import { team } from '../data/team.mjs';
import { teamGrid } from './team.mjs';

export function home() {
  const tf = publicAssets.find((a) => a.slug === 'twinfin');

  const body = html`
<section class="hero" data-hero>
  <div class="hero__media" data-hero-media>
    ${picture('areguling-coast', { alt: '', eager: true, sizes: '100vw', position: '50% 62%' })}
  </div>
  <div class="hero__shade" aria-hidden="true"></div>
  <div class="hero__content wrap">
    <p class="hero__eyebrow" data-hero-in><span class="rule" aria-hidden="true"></span>Investment holding company · Indonesia</p>
    <h1 class="hero__title" data-hero-in>
      <span class="hero__line">We don’t invest in projects.</span>
      <span class="hero__line"><em>We build a portfolio.</em></span>
    </h1>
    <div class="hero__aside" data-hero-in>
      <p>Oraya Collective builds, acquires and operates businesses and real assets across Indonesia — beginning in Lombok.</p>
      <div class="hero__actions">
        <a href="#collective" class="btn btn--solid-light">Explore the collective${arrow}</a>
        <a href="/investor-access/" class="text-link text-link--light">Investor access${arrow}</a>
      </div>
    </div>
  </div>
  <dl class="hero__strip" data-hero-in>
    <div><dt>Company</dt><dd>Investment holding</dd></div>
    <div><dt>Focus</dt><dd>Indonesia · Lombok</dd></div>
    <div><dt>Verticals</dt><dd>Real Estate · Hospitality · F&amp;B / Lifestyle</dd></div>
    <div><dt>In operation</dt><dd>TwinFin, since 2025</dd></div>
  </dl>
</section>

<section class="section" id="collective">
  <div class="wrap">
    ${sectionHead({ n: '01', label: 'The Collective' })}
    <div class="split">
      <h2 class="display-l split__main" data-reveal>One investment.<br><em>Multiple opportunities.</em></h2>
      <div class="split__side" data-reveal>
        <p class="lead">Rather than choosing a single villa or development, Oraya investors take a position in the company.</p>
        <p>Oraya, in turn, builds a portfolio of businesses and real assets across real estate, hospitality and lifestyle — each at its own stage, each under the ownership model that suits it.</p>
        ${textLink('/collective/', 'How the collective works')}
      </div>
    </div>
    ${collectiveDiagram(publicAssets)}
  </div>
</section>

<section class="section section--flush-top" id="portfolio">
  <div class="wrap">
    ${sectionHead({ n: '02', label: 'Portfolio register' })}
    <div class="split">
      <h2 class="display-l split__main" data-reveal>The register.</h2>
      <p class="split__side lead muted" data-reveal>Every position in the collective, with its stage and Oraya’s relationship stated plainly — the way a holding company reads its own book.</p>
    </div>
    ${register(publicAssets, { compact: true, id: 'home-register' })}
    <div class="section__foot" data-reveal>${textLink('/portfolio/', 'Open the full register')}</div>
  </div>
</section>

<section class="section section--dark" id="twinfin">
  <div class="wrap">
    ${sectionHead({ n: '03', label: 'In operation', light: true })}
    <div class="proof">
      <figure class="proof__media" data-reveal="image">
        ${picture(tf.images.hero.key, { alt: tf.images.hero.alt, sizes: '(max-width: 900px) 100vw, 46vw' })}
        <figcaption class="caption caption--light">TwinFin · Lombok</figcaption>
      </figure>
      <div class="proof__text">
        <h2 class="display-l" data-reveal>Already<br><em>operating.</em></h2>
        <p class="lead" data-reveal>TwinFin is a ten-room boutique surf house in Lombok and the first asset in the collective to trade. Small by design: built to fill, to form a community and to hold healthy margins.</p>
        <div data-reveal>${ledger([
          { label: 'Oraya’s position', value: relationshipText(tf) },
          { label: 'Status', value: 'Operating', html: statusTag(tf.status) },
          { label: 'Rooms', value: '10' },
          { label: 'Trading since', value: tf.since },
        ], true)}</div>
      </div>
    </div>
    <div class="proof__data">
      <div data-reveal>${metricsTable(tf.actualMetrics, true)}</div>
      <div data-reveal>${investorRoomPanel(tf.investorRoom, true)}</div>
    </div>
    <div class="section__foot" data-reveal>${textLink('/portfolio/twinfin/', 'Read the TwinFin case', true)}</div>
  </div>
</section>

<section class="section">
  <div class="wrap">
    ${sectionHead({ n: '04', label: 'Our model' })}
    <h2 class="display-l model-title" data-reveal>Build. Acquire.<br>Operate. <em>Grow.</em></h2>
    <ol class="model">
      ${model.map((m) => html`<li class="model__item" data-reveal>
        <span class="model__n">${m.numeral}</span>
        <h3 class="model__title">${esc(m.title)}</h3>
        <p>${esc(m.text)}</p>
        <span class="model__ex label">${esc(m.example)}</span>
      </li>`)}
    </ol>
  </div>
</section>

<section class="section section--stone">
  <div class="wrap">
    ${sectionHead({ n: '05', label: 'Why Indonesia' })}
    <div class="split">
      <h2 class="display-l split__main" data-reveal>Lombok.<br><em>Early, not late.</em></h2>
      <p class="split__side lead" data-reveal>${esc(lombok.intro)}</p>
    </div>
    <div class="facts">
      ${lombok.points.map((p) => html`<div class="facts__item" data-reveal>
        <span class="facts__figure">${esc(p.figure)}</span>
        <span class="label">${esc(p.label)}</span>
        <p>${esc(p.text)}</p>
      </div>`)}
    </div>
    <p class="footnote" data-reveal>${esc(lombok.sourceNote)}</p>
    <div class="section__foot" data-reveal>${textLink('/approach/', 'Our investment approach')}</div>
  </div>
</section>

<section class="section">
  <div class="wrap">
    ${sectionHead({ n: '06', label: 'The team' })}
    <div class="split">
      <h2 class="display-l split__main" data-reveal>Built locally.<br><em>Aligned by design.</em></h2>
      <p class="split__side lead" data-reveal>Oraya is run by an in-country team, with its own deal flow in the south of Lombok and a local operating company — and its founders hold equity in every project vehicle.</p>
    </div>
    ${when(team.length, () => teamGrid(team.slice(0, 4)))}
    <div class="principles">
      ${alignment.map((a) => html`<div class="principles__item" data-reveal><h3>${esc(a.title)}</h3><p>${esc(a.text)}</p></div>`)}
    </div>
    <div class="section__foot" data-reveal>${textLink('/team/', 'The people behind Oraya')}</div>
  </div>
</section>

<section class="access-band">
  <div class="access-band__media" aria-hidden="true">${picture('brand-cover', { alt: '', sizes: '100vw' })}</div>
  <div class="wrap access-band__inner">
    ${sectionHead({ n: '07', label: 'Investor access', light: true })}
    <h2 class="display-xl" data-reveal>Invest in the company<br><em>behind the projects.</em></h2>
    <div class="access-band__row" data-reveal>
      <p class="lead">We share the portfolio in detail — operating data, forecasts and structure — in a private conversation with qualified investors.</p>
      <a href="/investor-access/" class="btn btn--solid-light">Request investor information${arrow}</a>
    </div>
  </div>
</section>`;

  return layout({
    path: '/',
    title: 'Indonesia-focused investment holding company',
    body,
    theme: 'dark',
  });
}
