import { html, esc, when } from '../lib/html.mjs';
import { picture } from '../lib/image.mjs';
import { layout, arrow } from '../components/layout.mjs';
import {
  sectionHead, pageHero, register, ledger, metricsTable, investorRoomPanel, statusTag,
  relationshipText, assetVisual, fallbackTile, ctaBand, pad, textLink,
} from '../components/ui.mjs';
import { publicAssets } from '../data/assets.mjs';
import { verticals, relationships, statuses } from '../data/taxonomy.mjs';

export function portfolioPage() {
  const counts = {
    total: publicAssets.length,
    operating: publicAssets.filter((a) => a.status === 'operating').length,
  };
  const body = html`
${pageHero({
  eyebrow: 'Portfolio',
  title: 'The register.',
  intro: 'The businesses and real assets in the collective — held, in development or under study — each with its stage and Oraya’s relationship stated exactly.',
})}
<section class="section section--flush-top">
  <div class="wrap">
    ${register(publicAssets, { id: 'portfolio-register' })}
    <div class="register-key" data-reveal>
      <p class="label">Reading the register</p>
      <ul>
        ${Object.entries(statuses).filter(([k]) => publicAssets.some((a) => a.status === k)).map(([k]) => html`<li>${statusTag(k)}</li>`)}
      </ul>
      <p class="muted">Positions marked <em>under study</em> or <em>development concept</em> are opportunities Oraya is assessing or preparing. They are not completed holdings.</p>
    </div>
  </div>
</section>
${ctaBand({ title: 'The full picture,<br><em>in private.</em>', text: 'Operating data, forecasts and structure for each position are shared with qualified investors.' })}`;

  return layout({
    path: '/portfolio/',
    title: 'Portfolio',
    description: `The Oraya Collective register: ${counts.total} positions across real estate, hospitality and F&B / lifestyle in Lombok, Indonesia, with stage and Oraya’s relationship for each.`,
    body,
    jsonld: [{
      '@context': 'https://schema.org',
      '@type': 'ItemList',
      name: 'Oraya Collective portfolio',
      itemListElement: publicAssets.map((a, i) => ({ '@type': 'ListItem', position: i + 1, name: a.name, url: `/portfolio/${a.slug}/` })),
    }],
  });
}

// ── Asset page template ───────────────────────────────────────────────────────
export function assetPage(a) {
  const v = verticals[a.vertical];
  const rel = relationships[a.relationship?.type];
  const i = publicAssets.findIndex((x) => x.slug === a.slug);
  const next = publicAssets[(i + 1) % publicAssets.length];
  const prev = publicAssets[(i - 1 + publicAssets.length) % publicAssets.length];
  const related = publicAssets.filter((x) => x.slug !== a.slug).sort((x, y) => (y.vertical === a.vertical) - (x.vertical === a.vertical)).slice(0, 3);
  const hasHero = Boolean(a.images?.hero);
  const isOpportunity = rel && !rel.confirmed;

  const body = html`
<nav class="asset-bar" aria-label="Portfolio navigation">
  <div class="wrap asset-bar__inner">
    <a href="/portfolio/">← Portfolio</a>
    <span class="asset-bar__pos">${pad(a.index)} / ${pad(publicAssets.length)} — ${esc(a.name)}</span>
    <a href="/portfolio/${next.slug}/">Next · ${esc(next.name)} →</a>
  </div>
</nav>

<section class="asset-hero${hasHero ? '' : ' asset-hero--type'}">
  <div class="wrap asset-hero__grid">
    <div class="asset-hero__text">
      <p class="label" data-reveal>${pad(a.index)} · ${esc(v.label)} · ${esc(a.region || a.location)}</p>
      <h1 class="asset-hero__name" data-reveal>${esc(a.name)}</h1>
      <p class="asset-hero__sub" data-reveal><em>${esc(a.descriptor)}</em></p>
      <p class="lead" data-reveal>${esc(a.summary)}</p>
    </div>
    <figure class="asset-hero__media" data-reveal="image">
      ${hasHero ? picture(a.images.hero.key, { alt: a.images.hero.alt, eager: true, sizes: '(max-width: 900px) 100vw, 50vw' }) : fallbackTile(a, 'tile--fill tile--hero')}
    </figure>
  </div>
</section>

<div class="wrap">
  ${ledger([
    { label: 'Vertical', value: v.label },
    { label: 'Location', value: a.location },
    { label: 'Oraya’s relationship', value: rel?.label },
    { label: 'Participation', value: a.relationship?.participation },
    { label: 'Status', value: statuses[a.status].label, html: statusTag(a.status) },
    { label: 'Since', value: a.since },
  ])}
</div>

${when(isOpportunity, () => html`<div class="wrap"><p class="notice" data-reveal><strong>Opportunity.</strong> ${esc(a.name)} is ${a.status === 'under-study' ? 'under study' : 'a concept in development'}. It is presented as an opportunity, not as a completed holding.</p></div>`)}

<section class="section">
  <div class="wrap">
    <div class="asset-block" data-reveal>
      <h2 class="asset-block__label"><span>i</span>The asset</h2>
      <div class="asset-block__body">
        ${(a.overview || []).map((p, k) => html`<p class="${k === 0 ? 'lead' : ''}">${esc(p)}</p>`)}
      </div>
      ${when(a.facts?.length, () => html`<dl class="facts-list">${a.facts.map((f) => html`<div><dt>${esc(f.label)}</dt><dd>${esc(f.value)}</dd></div>`)}</dl>`)}
    </div>

    ${when(a.thesis, () => html`<div class="asset-block" data-reveal>
      <h2 class="asset-block__label"><span>ii</span>The thesis</h2>
      <blockquote class="thesis">${esc(a.thesis)}</blockquote>
    </div>`)}

    <div class="asset-block" data-reveal>
      <h2 class="asset-block__label"><span>iii</span>Oraya’s role</h2>
      <div class="asset-block__body">
        <p class="lead">${esc(relationshipText(a))}</p>
        <p>${roleSentence(a)}</p>
      </div>
    </div>
  </div>
</section>

${when(a.images?.gallery?.length, () => html`<section class="section section--flush-top"><div class="wrap">
  <div class="asset-gallery">${a.images.gallery.map((g) => html`<figure data-reveal="image">${picture(g.key, { alt: g.alt, sizes: '(max-width: 900px) 100vw, 60vw' })}</figure>`)}</div>
</div></section>`)}

${when(a.actualMetrics || a.investorRoom, () => html`<section class="section section--dark">
  <div class="wrap">
    ${sectionHead({ n: 'iv', label: 'Performance', light: true })}
    <h2 class="display-l" data-reveal>${a.actualMetrics ? 'What has happened,<br><em>and what is expected.</em>' : 'Figures,<br><em>shared in private.</em>'}</h2>
    <div class="proof__data">
      ${when(a.actualMetrics, () => html`<div data-reveal>${metricsTable(a.actualMetrics, true)}</div>`)}
      <div data-reveal>${investorRoomPanel(a.investorRoom, true)}</div>
    </div>
  </div>
</section>`)}

<section class="section">
  <div class="wrap">
    <div class="asset-block" data-reveal>
      <h2 class="asset-block__label"><span>v</span>Location</h2>
      <div class="asset-block__body"><p class="display-m">${esc(a.location)}</p>${a.location.includes('Indonesia') ? '' : '<p class="muted">Indonesia</p>'}</div>
    </div>
    <p class="footnote" data-reveal>Source: ${a.sources.map(esc).join('; ')}. ${hasHero ? 'Imagery as presented in the source document.' : ''}</p>
  </div>
</section>

<section class="section section--stone">
  <div class="wrap">
    ${sectionHead({ label: 'Elsewhere in the collective' })}
    <ul class="related">
      ${related.map((r) => html`<li class="related__item" data-reveal><a href="/portfolio/${r.slug}/">
        <div class="related__media">${assetVisual(r, { sizes: '(max-width: 760px) 100vw, 30vw', tileClass: 'tile--fill' })}</div>
        <div class="related__meta"><span class="related__name">${esc(r.name)}</span>${statusTag(r.status, 'status--sm')}</div>
        <span class="muted">${esc(verticals[r.vertical].label)} · ${esc(relationshipText(r))}</span>
      </a></li>`)}
    </ul>
  </div>
</section>

<a href="/portfolio/${next.slug}/" class="next-asset">
  <span class="wrap next-asset__inner"><span class="label">Next position · ${pad(next.index)}</span><span class="next-asset__name">${esc(next.name)}</span><span class="next-asset__arrow" aria-hidden="true">→</span></span>
</a>`;

  return layout({
    path: `/portfolio/${a.slug}/`,
    title: `${a.name} — ${v.label}, ${a.region || a.location}`,
    description: `${a.summary}`.slice(0, 160),
    body,
    ogImage: a.images?.hero?.key || 'brand-cover',
    jsonld: [{
      '@context': 'https://schema.org',
      '@type': 'Place',
      name: a.name,
      description: a.summary,
      address: { '@type': 'PostalAddress', addressRegion: a.region, addressCountry: 'ID' },
    }],
  });
}

function roleSentence(a) {
  switch (a.relationship?.type) {
    case 'ownership':
      return `Oraya holds ${esc(a.relationship.participation)} of ${esc(a.name)}.`;
    case 'portfolio-project':
      return `${esc(a.name)} is part of Oraya’s portfolio as a development project. Further details are shared with qualified investors.`;
    case 'minority-under-study':
      return `Oraya is studying a minority participation in ${esc(a.name)}. Data is preliminary.`;
    case 'development-concept':
      return `${esc(a.name)} is a concept in development within the collective. It is not yet operating.`;
    case 'structured-financing':
      return `Oraya’s position in ${esc(a.name)} takes the form of structured financing.`;
    default:
      return '';
  }
}
