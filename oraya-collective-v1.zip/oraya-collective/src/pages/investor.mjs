import { html } from '../lib/html.mjs';
import { layout, arrow } from '../components/layout.mjs';
import { sectionHead } from '../components/ui.mjs';

const field = ({ name, label, type = 'text', required = false, autocomplete = '', hint = '', full = false }) => html`
  <div class="field${full ? ' field--full' : ''}">
    <label for="f-${name}">${label}${required ? '' : ' <span class="field__opt">Optional</span>'}</label>
    <input id="f-${name}" name="${name}" type="${type}"${required ? ' required' : ''}${autocomplete ? ` autocomplete="${autocomplete}"` : ''}${hint ? ` aria-describedby="f-${name}-hint"` : ''}>
    ${hint ? html`<p class="field__hint" id="f-${name}-hint">${hint}</p>` : ''}
    <p class="field__error" data-error-for="${name}" hidden></p>
  </div>`;

const select = ({ name, label, options, required = false }) => html`
  <div class="field">
    <label for="f-${name}">${label}${required ? '' : ' <span class="field__opt">Optional</span>'}</label>
    <select id="f-${name}" name="${name}"${required ? ' required' : ''}>
      <option value="">Select</option>
      ${options.map((o) => html`<option>${o}</option>`)}
    </select>
    <p class="field__error" data-error-for="${name}" hidden></p>
  </div>`;

export function investorPage() {
  const body = html`
<section class="page-hero page-hero--access">
  <div class="wrap">
    ${sectionHead({ label: 'Investor access' })}
    <div class="page-hero__grid">
      <h1 class="display-xl" data-reveal>A private<br><em>conversation.</em></h1>
      <p class="lead page-hero__intro" data-reveal>Tell us a little about yourself. A member of the founding team will reply personally to arrange an introduction to the collective.</p>
    </div>
  </div>
</section>

<section class="section section--flush-top">
  <div class="wrap access">
    <aside class="access__side" data-reveal>
      <ol class="steps">
        <li><span class="steps__n">1</span><div><h2>Request</h2><p>Share your details and what you would like to know.</p></div></li>
        <li><span class="steps__n">2</span><div><h2>Introduction</h2><p>A private call with one of the founders.</p></div></li>
        <li><span class="steps__n">3</span><div><h2>Investor room</h2><p>Operating data, forecasts and structure, position by position — shared with qualified investors.</p></div></li>
      </ol>
      <p class="muted small">Submitting this form is not an application to invest and creates no obligation on either side. Information on this website does not constitute an offer of securities.</p>
    </aside>

    <form class="form" name="investor-access" method="POST" action="/investor-access/thank-you/" data-netlify="true" netlify-honeypot="company-website" novalidate data-form>
      <input type="hidden" name="form-name" value="investor-access">
      <p class="visually-hidden"><label>Leave this field empty <input name="company-website" tabindex="-1" autocomplete="off"></label></p>

      <fieldset class="form__group">
        <legend class="label">About you</legend>
        <div class="form__grid">
          ${field({ name: 'first-name', label: 'First name', required: true, autocomplete: 'given-name' })}
          ${field({ name: 'last-name', label: 'Last name', required: true, autocomplete: 'family-name' })}
          ${field({ name: 'email', label: 'Email', type: 'email', required: true, autocomplete: 'email' })}
          ${field({ name: 'phone', label: 'Phone', type: 'tel', autocomplete: 'tel' })}
          ${field({ name: 'country', label: 'Country of residence', required: true, autocomplete: 'country-name' })}
          ${field({ name: 'organisation', label: 'Company or family office', autocomplete: 'organization' })}
        </div>
      </fieldset>

      <fieldset class="form__group">
        <legend class="label">Your enquiry</legend>
        <div class="form__grid">
          ${select({ name: 'profile', label: 'You are contacting us as', required: true, options: ['Private investor', 'Family office', 'Company or corporate investor', 'Adviser or intermediary', 'Landowner, operator or partner', 'Press'] })}
          ${select({ name: 'range', label: 'Indicative allocation', options: ['Under €100,000', '€100,000 – €250,000', '€250,000 – €1,000,000', 'Over €1,000,000', 'Prefer to discuss'] })}
        </div>
        <div class="field field--full">
          <span class="field__label" id="interest-label">Areas of interest <span class="field__opt">Optional</span></span>
          <div class="checks" role="group" aria-labelledby="interest-label">
            <label class="check"><input type="checkbox" name="interest" value="The collective as a whole"><span>The collective as a whole</span></label>
            <label class="check"><input type="checkbox" name="interest" value="TwinFin"><span>TwinFin</span></label>
            <label class="check"><input type="checkbox" name="interest" value="Real estate"><span>Real estate</span></label>
            <label class="check"><input type="checkbox" name="interest" value="Hospitality"><span>Hospitality</span></label>
            <label class="check"><input type="checkbox" name="interest" value="F&amp;B / Lifestyle"><span>F&amp;B / Lifestyle</span></label>
            <label class="check"><input type="checkbox" name="interest" value="Proposing an opportunity"><span>Proposing an opportunity</span></label>
          </div>
        </div>
        <div class="field field--full">
          <label for="f-message">Message <span class="field__opt">Optional</span></label>
          <textarea id="f-message" name="message" rows="5"></textarea>
        </div>
      </fieldset>

      <div class="form__consent">
        <label class="check check--consent"><input type="checkbox" name="consent" value="yes" required><span>I have read the <a href="/legal/privacy/">privacy notice</a> and agree to Oraya Collective contacting me about this enquiry.</span></label>
        <p class="field__error" data-error-for="consent" hidden></p>
      </div>

      <div class="form__submit">
        <button type="submit" class="btn btn--solid">Request investor information${arrow}</button>
        <p class="form__status" role="status" aria-live="polite" data-form-status></p>
      </div>
    </form>
  </div>
</section>`;

  return layout({
    path: '/investor-access/',
    title: 'Investor access',
    description: 'Request investor information from Oraya Collective. A member of the founding team will reply personally.',
    body,
    stickyCta: false,
  });
}

export function thankYouPage() {
  const body = html`
<section class="page-hero page-hero--thanks">
  <div class="wrap">
    ${sectionHead({ label: 'Investor access' })}
    <h1 class="display-xl" data-reveal>Thank you.<br><em>We’ll be in touch.</em></h1>
    <p class="lead page-hero__intro" data-reveal>Your request has been received. A member of the founding team will reply personally.</p>
    <div class="hero__actions" data-reveal>
      <a href="/portfolio/" class="btn btn--solid">Explore the portfolio${arrow}</a>
      <a href="/" class="text-link">Return home${arrow}</a>
    </div>
  </div>
</section>`;
  return layout({ path: '/investor-access/thank-you/', title: 'Thank you', body, noindex: true, stickyCta: false });
}
