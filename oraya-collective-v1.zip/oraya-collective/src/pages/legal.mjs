// Legal pages. Kept deliberately separate from marketing copy.
// DRAFTS — to be reviewed and completed by counsel before public launch
// (company registration details, registered address and contact channel
// are not yet confirmed and are therefore omitted, not invented).

import { html } from '../lib/html.mjs';
import { layout } from '../components/layout.mjs';
import { legalNav } from '../config/site.mjs';

function legalShell({ path, title, intro, sections }) {
  const body = html`
<!-- DRAFT: review by counsel before launch -->
<section class="legal">
  <div class="wrap legal__grid">
    <aside class="legal__nav">
      <p class="label">Legal</p>
      <nav aria-label="Legal documents">${legalNav.map((n) => html`<a href="${n.href}"${n.href === path ? ' aria-current="page"' : ''}>${n.label}</a>`)}</nav>
    </aside>
    <article class="legal__doc">
      <h1 class="display-m">${title}</h1>
      <p class="legal__intro">${intro}</p>
      ${sections.map((s) => html`<h2>${s.h}</h2>${s.p.map((p) => html`<p>${p}</p>`)}`)}
    </article>
  </div>
</section>`;
  return layout({ path, title, description: `${title} — Oraya Collective.`, body, stickyCta: false });
}

export const legalPages = [
  {
    path: '/legal/investment-disclaimer/',
    title: 'Investment disclaimer',
    intro: 'Please read this disclaimer before relying on any information on this website.',
    sections: [
      { h: 'Information only', p: ['This website is published by Oraya Collective (The Oraya Collective SL and PT Oraya Collective Indonesia) for general information about the company and its activities. It does not constitute an offer to sell, or a solicitation of an offer to buy, any shares, units, securities or other investment, in any jurisdiction.'] },
      { h: 'No advice', p: ['Nothing on this website is investment, legal, tax or financial advice, or a recommendation to make any investment. You should obtain independent professional advice before making any investment decision.'] },
      { h: 'Figures and labels', p: ['Figures on this website are labelled. <strong>Actual</strong> figures are reported historical results. Figures labelled <strong>forecast</strong>, <strong>preliminary</strong> or <strong>projected</strong> are estimates based on assumptions that may not be realised; actual results may differ materially. Past performance is not a reliable indicator of future results.', 'Positions described as <strong>under study</strong> or as a <strong>development concept</strong> are opportunities being assessed or prepared and are not completed investments.'] },
      { h: 'Risk', p: ['Investments in private companies, real estate and hospitality businesses in emerging markets involve significant risk, including the possible loss of the entire amount invested, illiquidity, currency, regulatory and political risk.'] },
      { h: 'Jurisdictions', p: ['This website is not directed at any person in any jurisdiction where its publication or availability would be contrary to local law or regulation, or would require registration or licensing.'] },
      { h: 'Imagery', p: ['Images and renders are illustrative. Renders are artistic impressions and may not reflect the finished asset.'] },
    ],
  },
  {
    path: '/legal/privacy/',
    title: 'Privacy notice',
    intro: 'How Oraya Collective handles personal data submitted through this website.',
    sections: [
      { h: 'Controller', p: ['The data controller is The Oraya Collective SL, a company established in Spain.'] },
      { h: 'Data we collect', p: ['When you complete the investor access form we collect the information you provide: name, email address, country of residence and, optionally, phone number, organisation, investor profile, indicative allocation, areas of interest and your message.'] },
      { h: 'Purpose and legal basis', p: ['We use this data to respond to your enquiry and to arrange an introduction, on the basis of your consent and of steps taken at your request prior to any agreement (Article 6(1)(a) and (b) GDPR).'] },
      { h: 'Processors and transfers', p: ['Form submissions are processed by our hosting provider, Netlify, Inc. Typography is served by Google Fonts. These providers may process data outside the European Economic Area under appropriate safeguards.'] },
      { h: 'Retention', p: ['We keep enquiry data for as long as needed to handle your enquiry and any resulting relationship, and delete it when it is no longer necessary.'] },
      { h: 'Your rights', p: ['You may request access to, rectification or erasure of your data, restriction of or objection to processing, and data portability, and you may withdraw consent at any time. You may also lodge a complaint with the Spanish Data Protection Agency (AEPD).'] },
    ],
  },
  {
    path: '/legal/terms/',
    title: 'Terms of use',
    intro: 'These terms govern your use of this website.',
    sections: [
      { h: 'Use of the website', p: ['You may use this website for lawful, personal and informational purposes. You must not misuse it, attempt to gain unauthorised access to it, or interfere with its operation.'] },
      { h: 'Intellectual property', p: ['The content, design, text and images on this website are owned by or licensed to Oraya Collective and may not be reproduced without prior written consent.'] },
      { h: 'Accuracy', p: ['We take care to keep information accurate and up to date, but give no warranty as to its completeness or accuracy. Information may change without notice. See also the investment disclaimer.'] },
      { h: 'Liability', p: ['To the extent permitted by law, Oraya Collective accepts no liability for loss arising from use of, or reliance on, this website.'] },
      { h: 'Governing law', p: ['These terms are governed by the laws of Spain.'] },
    ],
  },
  {
    path: '/legal/cookies/',
    title: 'Cookie policy',
    intro: 'This website does not set advertising or analytics cookies.',
    sections: [
      { h: 'What we use', p: ['This website sets no cookies of its own. Typography is loaded from Google Fonts, which receives your IP address when the fonts are requested.', 'If analytics or other cookies are introduced in future, this policy will be updated and your consent requested where required.'] },
    ],
  },
].map((d) => ({ path: d.path, render: () => legalShell(d) }));

export function notFoundPage() {
  const body = html`
<section class="page-hero page-hero--thanks">
  <div class="wrap">
    <p class="label">404</p>
    <h1 class="display-xl">This page<br><em>is not in the register.</em></h1>
    <div class="hero__actions"><a href="/" class="btn btn--solid">Return home</a><a href="/portfolio/" class="text-link">View the portfolio →</a></div>
  </div>
</section>`;
  return layout({ path: '/404.html', title: 'Page not found', body, noindex: true, stickyCta: false });
}
