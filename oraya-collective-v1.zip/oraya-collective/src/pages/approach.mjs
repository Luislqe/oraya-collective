import { html, esc } from '../lib/html.mjs';
import { layout } from '../components/layout.mjs';
import { sectionHead, pageHero, ctaBand, dataLabel } from '../components/ui.mjs';
import { lombok } from '../data/content.mjs';
import { dataKinds } from '../data/taxonomy.mjs';

const criteria = [
  { t: 'Location we know', d: 'We invest where our team works. Today that is Lombok, with our own deal flow in the south of the island.' },
  { t: 'An operating case', d: 'We favour assets that can trade — hospitality, F&B, residences — and that we can run or oversee through our local company.' },
  { t: 'Fit with the collective', d: 'Each new position should share infrastructure, channels or know-how with the others, so the platform grows without multiplying structure.' },
  { t: 'The right ownership model', d: 'Ownership, development, minority participation or structured financing — the structure follows the asset, not the other way round.' },
  { t: 'Alignment', d: 'Every asset sits in its own ring-fenced vehicle, and the founders hold equity in each one.' },
];

const process = [
  { t: 'Source', d: 'Opportunities come through our established local network and our in-country team.' },
  { t: 'Study', d: 'We assess the site, the operating case and the numbers. Positions under study are published as such — never as holdings.' },
  { t: 'Structure', d: 'Each asset is placed in its own vehicle, under the ownership model that suits it.' },
  { t: 'Build or acquire', d: 'We develop from the ground up, or invest in what already exists.' },
  { t: 'Operate and report', d: 'We stay involved after the investment, and report each position with its data clearly labelled.' },
];

export function approachPage() {
  const body = html`
${pageHero({
  eyebrow: 'Approach',
  title: 'How we choose,<br><em>and how we build.</em>',
  intro: 'Oraya invests where it can add value on the ground: in businesses and land it understands, structured one asset at a time, and operated by its own people.',
})}

<section class="section section--flush-top">
  <div class="wrap">
    ${sectionHead({ n: '01', label: 'What we look for' })}
    <ol class="rows">
      ${criteria.map((c, i) => html`<li class="rows__item" data-reveal><span class="rows__n">0${i + 1}</span><h3 class="rows__title">${esc(c.t)}</h3><p>${esc(c.d)}</p></li>`)}
    </ol>
  </div>
</section>

<section class="section section--dark">
  <div class="wrap">
    ${sectionHead({ n: '02', label: 'From opportunity to operation', light: true })}
    <h2 class="display-l" data-reveal>Five stages,<br><em>one discipline.</em></h2>
    <ol class="process">
      ${process.map((p, i) => html`<li class="process__item" data-reveal><span class="process__n">${i + 1}</span><h3>${esc(p.t)}</h3><p>${esc(p.d)}</p></li>`)}
    </ol>
  </div>
</section>

<section class="section">
  <div class="wrap">
    ${sectionHead({ n: '03', label: 'Why Lombok' })}
    <div class="split">
      <h2 class="display-l split__main" data-reveal>Early,<br><em>not late.</em></h2>
      <p class="split__side lead" data-reveal>${esc(lombok.intro)}</p>
    </div>
    <div class="facts">
      ${lombok.points.map((p) => html`<div class="facts__item" data-reveal><span class="facts__figure">${esc(p.figure)}</span><span class="label">${esc(p.label)}</span><p>${esc(p.text)}</p></div>`)}
    </div>
    <p class="footnote" data-reveal>${esc(lombok.sourceNote)}</p>
  </div>
</section>

<section class="section section--stone">
  <div class="wrap">
    ${sectionHead({ n: '04', label: 'How we report' })}
    <div class="split">
      <h2 class="display-l split__main" data-reveal>What has happened,<br><em>and what is expected.</em></h2>
      <p class="split__side lead" data-reveal>Every figure we share carries a label. Results and projections are never mixed in the same block, and opportunities under study are never presented as holdings.</p>
    </div>
    <dl class="labels-key">
      ${Object.entries(dataKinds).map(([k, v]) => html`<div class="labels-key__item" data-reveal><dt>${dataLabel(k)}</dt><dd>${esc(v.note)}</dd></div>`)}
    </dl>
  </div>
</section>

${ctaBand({ title: 'Discuss<br><em>an investment.</em>', text: 'We walk qualified investors through the portfolio, position by position.' })}`;

  return layout({
    path: '/approach/',
    title: 'Approach',
    description: 'How Oraya Collective sources, studies, structures, builds and operates its positions — and how it labels every figure it reports.',
    body,
  });
}
