/* Oraya Collective — progressive enhancement. No dependencies. */
(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- Header: solid after scroll, hide on scroll down ---------- */
  const header = $('[data-header]');
  const hero = $('[data-hero]');
  const sticky = $('[data-sticky-cta]');
  let lastY = window.scrollY;
  let ticking = false;
  const onScroll = () => {
    const y = window.scrollY;
    const threshold = hero ? Math.max(hero.offsetHeight - 120, 80) : 24;
    if (header) {
      header.classList.toggle('is-solid', y > (hero ? threshold * 0.5 : 24));
      const goingDown = y > lastY && y > 240;
      header.classList.toggle('is-hidden', goingDown && !document.body.classList.contains('menu-open'));
    }
    if (sticky) sticky.classList.toggle('is-visible', y > (hero ? threshold : 360));
    lastY = y;
    ticking = false;
  };
  window.addEventListener('scroll', () => { if (!ticking) { requestAnimationFrame(onScroll); ticking = true; } }, { passive: true });
  onScroll();

  /* ---------- Hero entrance ---------- */
  if (hero) requestAnimationFrame(() => setTimeout(() => hero.classList.add('is-ready'), 60));

  /* ---------- Mobile menu ---------- */
  const menu = $('[data-menu]');
  const openBtn = $('[data-menu-open]');
  const closeBtn = $('[data-menu-close]');
  let lastFocus = null;
  const focusables = () => $$('a, button', menu).filter((el) => !el.hasAttribute('disabled'));
  const openMenu = () => {
    lastFocus = document.activeElement;
    menu.hidden = false;
    document.body.classList.add('menu-open');
    document.body.style.overflow = 'hidden';
    openBtn.setAttribute('aria-expanded', 'true');
    requestAnimationFrame(() => menu.classList.add('is-open'));
    setTimeout(() => closeBtn.focus(), 50);
  };
  const closeMenu = () => {
    menu.classList.remove('is-open');
    document.body.classList.remove('menu-open');
    document.body.style.overflow = '';
    openBtn.setAttribute('aria-expanded', 'false');
    setTimeout(() => { menu.hidden = true; }, reduced ? 0 : 300);
    if (lastFocus) lastFocus.focus();
  };
  if (menu && openBtn) {
    openBtn.addEventListener('click', openMenu);
    closeBtn.addEventListener('click', closeMenu);
    menu.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') closeMenu();
      if (e.key === 'Tab') {
        const f = focusables();
        const first = f[0];
        const last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    });
    $$('a', menu).forEach((a) => a.addEventListener('click', () => {
      if (a.getAttribute('href').startsWith('#')) closeMenu();
    }));
  }

  /* ---------- Scroll reveals ---------- */
  const revealEls = $$('[data-reveal], [data-diagram]');
  if (!('IntersectionObserver' in window) || reduced) {
    revealEls.forEach((el) => el.classList.add('is-in'));
  } else {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((en) => {
        if (en.isIntersecting) { en.target.classList.add('is-in'); io.unobserve(en.target); }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
    revealEls.forEach((el) => io.observe(el));
    // Safety net: never leave content hidden.
    setTimeout(() => revealEls.forEach((el) => {
      const r = el.getBoundingClientRect();
      if (r.top < window.innerHeight) el.classList.add('is-in');
    }), 1600);
  }

  /* ---------- Portfolio register ---------- */
  $$('[data-register]').forEach((reg) => {
    const state = { vertical: 'all', stage: 'all', sort: 'index', view: 'register' };
    const panels = { register: $('[data-panel="register"]', reg), gallery: $('[data-panel="gallery"]', reg) };
    const lists = $$('[data-items]', reg);
    const countEl = $('[data-count]', reg);
    const emptyEl = $('[data-empty]', reg);
    const total = $$('[data-item]', lists[0]).length;
    const pad = (n) => String(n).padStart(2, '0');

    const matches = (el) =>
      (state.vertical === 'all' || el.dataset.vertical === state.vertical) &&
      (state.stage === 'all' || el.dataset.stage === state.stage);

    const sortList = (list) => {
      const items = $$('[data-item]', list);
      items.sort((a, b) => {
        if (state.sort === 'name') return a.dataset.name.localeCompare(b.dataset.name);
        if (state.sort === 'order') return (+a.dataset.order - +b.dataset.order) || (+a.dataset.index - +b.dataset.index);
        return +a.dataset.index - +b.dataset.index;
      });
      items.forEach((el) => list.appendChild(el));
    };

    const apply = () => {
      let shown = 0;
      lists.forEach((list, li) => {
        sortList(list);
        $$('[data-item]', list).forEach((el) => {
          const ok = matches(el);
          if (ok && li === 0) shown++;
          if (ok && el.hidden) {
            el.hidden = false;
            el.classList.remove('is-leaving');
            if (!reduced) { el.classList.add('is-entering'); setTimeout(() => el.classList.remove('is-entering'), 460); }
          } else if (!ok && !el.hidden) {
            if (reduced) { el.hidden = true; return; }
            el.classList.add('is-leaving');
            setTimeout(() => { if (!matches(el)) el.hidden = true; el.classList.remove('is-leaving'); }, 220);
          }
        });
      });
      if (countEl) countEl.textContent = `${pad(shown)} of ${pad(total)}`;
      if (emptyEl) emptyEl.hidden = shown !== 0;
    };

    $$('[data-filter]', reg).forEach((btn) => btn.addEventListener('click', () => {
      const group = btn.dataset.filter;
      state[group] = btn.dataset.value;
      $$(`[data-filter="${group}"]`, reg).forEach((b) => b.setAttribute('aria-pressed', String(b === btn)));
      apply();
    }));
    const sortSel = $('[data-sort]', reg);
    if (sortSel) sortSel.addEventListener('change', () => { state.sort = sortSel.value; apply(); });

    $$('[data-view]', reg).forEach((btn) => btn.addEventListener('click', () => {
      state.view = btn.dataset.view;
      $$('[data-view]', reg).forEach((b) => b.setAttribute('aria-pressed', String(b === btn)));
      Object.entries(panels).forEach(([k, p]) => {
        if (!p) return;
        p.hidden = k !== state.view;
        if (!p.hidden && !reduced) { p.classList.remove('is-entering'); void p.offsetWidth; p.classList.add('is-entering'); }
      });
      hidePreview();
    }));

    /* Hover preview (fine pointers only) */
    const box = $('[data-preview-box]', reg);
    const body = $('.register__body', reg);
    let raf = null;
    const hidePreview = () => { if (box) box.classList.remove('is-visible'); };
    if (box && window.matchMedia('(hover: hover) and (pointer: fine)').matches) {
      const imgs = $$('[data-preview-for]', box);
      $$('.reg-row', reg).forEach((row) => {
        row.addEventListener('mouseenter', () => {
          const target = imgs.find((i) => i.dataset.previewFor === row.dataset.preview);
          imgs.forEach((i) => i.classList.toggle('is-active', i === target));
          box.classList.toggle('is-visible', Boolean(target));
        });
        row.addEventListener('mouseleave', hidePreview);
      });
      body.addEventListener('mousemove', (e) => {
        if (raf) cancelAnimationFrame(raf);
        raf = requestAnimationFrame(() => {
          const r = body.getBoundingClientRect();
          const x = Math.min(e.clientX - r.left + 32, r.width - 250);
          const y = e.clientY - r.top - 150;
          box.style.transform = `translate3d(${x}px, ${y}px, 0)`;
        });
      });
    }
    apply();
  });

  /* ---------- Investor access form ---------- */
  const form = $('[data-form]');
  if (form) {
    const status = $('[data-form-status]', form);
    const messages = {
      valueMissing: 'This field is required.',
      typeMismatch: 'Please enter a valid email address.',
    };
    const setError = (input, msg) => {
      const holder = $(`[data-error-for="${input.name}"]`, form);
      const field = input.closest('.field');
      if (field) field.classList.toggle('has-error', Boolean(msg));
      input.setAttribute('aria-invalid', msg ? 'true' : 'false');
      if (holder) {
        holder.textContent = msg || '';
        holder.hidden = !msg;
        if (msg) { holder.id = holder.id || `err-${input.name}`; input.setAttribute('aria-describedby', holder.id); }
      }
    };
    const validate = (input) => {
      if (input.name === 'consent' && !input.checked) { setError(input, 'Please confirm you have read the privacy notice.'); return false; }
      const v = input.validity;
      const key = Object.keys(messages).find((k) => v[k]);
      setError(input, key ? messages[key] : '');
      return !key;
    };
    const required = $$('[required]', form);
    required.forEach((i) => i.addEventListener('blur', () => { if (i.value || i.type === 'checkbox') validate(i); }));
    required.forEach((i) => i.addEventListener('input', () => { if (i.getAttribute('aria-invalid') === 'true') validate(i); }));

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const invalid = required.filter((i) => !validate(i));
      if (invalid.length) {
        invalid[0].focus();
        status.textContent = 'Please complete the highlighted fields.';
        return;
      }
      const btn = $('button[type="submit"]', form);
      btn.disabled = true;
      status.textContent = 'Sending…';
      try {
        const data = new URLSearchParams(new FormData(form)).toString();
        // Netlify Forms: AJAX submissions are posted to "/" with form-name.
        const res = await fetch('/', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: data,
        });
        if (!res.ok) throw new Error(String(res.status));
        window.location.href = form.getAttribute('action');
      } catch (err) {
        btn.disabled = false;
        status.textContent = 'Something went wrong. Please try again in a moment.';
      }
    });
  }
})();
