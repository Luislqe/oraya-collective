// Generates responsive WebP + JPEG variants for every image in /assets-src
// and writes src/data/image-manifest.json.
//
// Run locally after adding or replacing an image:   npm run images
// The generated files in /public/images and the manifest are committed,
// so the Netlify build itself needs no image tooling.

import { readdir, mkdir, writeFile } from 'node:fs/promises';
import { join, parse } from 'node:path';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
let sharp;
try {
  sharp = require('sharp');
} catch {
  try {
    sharp = require('/opt/npm-tools/node_modules/sharp');
  } catch {
    console.error('sharp is not installed. Run `npm install` first.');
    process.exit(1);
  }
}

const ROOT = new URL('..', import.meta.url).pathname;
const SRC = join(ROOT, 'assets-src');
const OUT = join(ROOT, 'public', 'images');
const MANIFEST = join(ROOT, 'src', 'data', 'image-manifest.json');
const WIDTHS = [480, 800, 1200, 1600, 2000];

await mkdir(OUT, { recursive: true });
const files = (await readdir(SRC)).filter((f) => /\.(jpe?g|png|webp)$/i.test(f)).sort();
const manifest = {};

for (const file of files) {
  const key = parse(file).name;
  const input = sharp(join(SRC, file)).rotate();
  const meta = await input.metadata();
  const widths = WIDTHS.filter((w) => w < meta.width);
  widths.push(meta.width);
  const variants = [];
  for (const w of [...new Set(widths)]) {
    const base = `${key}-${w}`;
    const resized = sharp(join(SRC, file)).rotate().resize({ width: w, withoutEnlargement: true });
    await resized.clone().webp({ quality: 78, effort: 5 }).toFile(join(OUT, `${base}.webp`));
    await resized.clone().jpeg({ quality: 80, progressive: true, mozjpeg: true }).toFile(join(OUT, `${base}.jpg`));
    variants.push(w);
  }
  const { dominant } = await sharp(join(SRC, file)).stats();
  manifest[key] = {
    width: meta.width,
    height: meta.height,
    widths: variants,
    color: `rgb(${dominant.r},${dominant.g},${dominant.b})`,
  };
  console.log(`✓ ${key} (${meta.width}×${meta.height}) → ${variants.join(', ')}`);
}

await writeFile(MANIFEST, JSON.stringify(manifest, null, 2) + '\n');
console.log(`\nManifest written: ${Object.keys(manifest).length} images.`);
