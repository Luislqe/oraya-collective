// Static build. Zero dependencies: Node ≥ 20 only.
//   node scripts/build.mjs   →   /dist
import { rm, mkdir, writeFile, cp, readFile } from 'node:fs/promises';
import { join, dirname } from 'node:path';

const ROOT = new URL('..', import.meta.url).pathname;
const DIST = join(ROOT, 'dist');
const bust = `?v=${Date.now().toString(36)}`;

export async function build({ quiet = false } = {}) {
  const t0 = Date.now();
  // Fresh imports on every build (dev server rebuilds in-process).
  const q = `?t=${Date.now()}`;
  const { site } = await import(`../src/config/site.mjs${q}`);
  const { publicAssets } = await import(`../src/data/assets.mjs${q}`);
  const { home } = await import(`../src/pages/home.mjs${q}`);
  const { collectivePage } = await import(`../src/pages/collective.mjs${q}`);
  const { portfolioPage, assetPage } = await import(`../src/pages/portfolio.mjs${q}`);
  const { approachPage } = await import(`../src/pages/approach.mjs${q}`);
  const { teamPage } = await import(`../src/pages/team.mjs${q}`);
  const { investorPage, thankYouPage } = await import(`../src/pages/investor.mjs${q}`);
  const { legalPages, notFoundPage } = await import(`../src/pages/legal.mjs${q}`);

  const pages = [
    { path: '/', render: home, priority: '1.0' },
    { path: '/collective/', render: collectivePage, priority: '0.8' },
    { path: '/portfolio/', render: portfolioPage, priority: '0.9' },
    ...publicAssets.map((a) => ({ path: `/portfolio/${a.slug}/`, render: () => assetPage(a), priority: a.featured ? '0.8' : '0.6' })),
    { path: '/approach/', render: approachPage, priority: '0.7' },
    { path: '/team/', render: teamPage, priority: '0.6' },
    { path: '/investor-access/', render: investorPage, priority: '0.8' },
    { path: '/investor-access/thank-you/', render: thankYouPage, noindex: true },
    ...legalPages.map((p) => ({ ...p, priority: '0.2' })),
    { path: '/404.html', render: notFoundPage, file: '404.html', noindex: true },
  ];

  await rm(DIST, { recursive: true, force: true });
  await mkdir(join(DIST, 'assets'), { recursive: true });
  await cp(join(ROOT, 'public'), DIST, { recursive: true });

  const css = await readFile(join(ROOT, 'src/styles/main.css'), 'utf8');
  await writeFile(join(DIST, 'assets/main.css'), minifyCss(css));
  await cp(join(ROOT, 'src/scripts/main.js'), join(DIST, 'assets/main.js'));

  for (const p of pages) {
    let out = p.render();
    out = out.replace('/assets/main.css"', `/assets/main.css${bust}"`).replace('/assets/main.js"', `/assets/main.js${bust}"`);
    const file = p.file ? join(DIST, p.file) : join(DIST, p.path, 'index.html');
    await mkdir(dirname(file), { recursive: true });
    await writeFile(file, out);
  }

  const today = new Date().toISOString().slice(0, 10);
  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${pages.filter((p) => !p.noindex).map((p) => `  <url><loc>${site.url}${p.path}</loc><lastmod>${today}</lastmod><priority>${p.priority}</priority></url>`).join('\n')}
</urlset>
`;
  await writeFile(join(DIST, 'sitemap.xml'), sitemap);
  await writeFile(join(DIST, 'robots.txt'), `User-agent: *\nAllow: /\nDisallow: /investor-access/thank-you/\n\nSitemap: ${site.url}/sitemap.xml\n`);

  if (!quiet) console.log(`✓ Built ${pages.length} pages to /dist in ${Date.now() - t0} ms (site: ${site.url})`);
  return pages;
}

function minifyCss(s) {
  return s
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/\s+/g, ' ')
    .replace(/\s*([{}:;,>])\s*/g, '$1')
    .replace(/;}/g, '}')
    .trim();
}

if (import.meta.url === `file://${process.argv[1]}`) {
  build().catch((e) => {
    console.error(e);
    process.exit(1);
  });
}
